drop database if exists qh710;
create DATABASE qh710;
use qh710;

drop table if exists qh710_dep;
create table qh710_dep (
dep_id INT unsigned NOT NULL AUTO_INCREMENT,
dep_name varchar(100) NOT NULL,
father_id int(10),
create_time TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
PRIMARY KEY (dep_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


drop table if exists qh710_user;
create table qh710_user (
user_id int(10) unsigned NOT NULL AUTO_INCREMENT,
user_name varchar(100) NOT NULL,
user_account varchar(100) NOT NULL,
user_password varchar(100) NOT NULL,
dep_id int(10) NOT NULL,
user_post varchar(100),
user_sex int(10) NOT NULL,
user_nation varchar(100),
user_birth varchar(100),
user_phone1 varchar(100),
user_phone2 varchar(100),
user_logintime TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
login_times INT(100) default 0,
user_address varchar(100),
user_email varchar(100),
user_auth varchar(10) NOT NULL,
token varchar(100),
PRIMARY KEY (user_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into qh710_user 
(user_name,user_account,user_password,dep_id,user_sex,user_auth)
values
('超级管理员','admin','21232f297a57a5a743894a0e4a801fc3',0,1,1000);

drop table if exists qh710_matter;
create table qh710_matter (
matter_id int(10) unsigned NOT NULL AUTO_INCREMENT,
matter_depid int(10) NOT NULL,
matter_issecret  int(2) NOT NULL,
matter_title varchar(200),
matter_from varchar(200) NOT NULL,
matter_task varchar(200) NOT NULL,
matter_deltime varchar(100) NOT NULL,
matter_deldep int(10) NOT NULL,
complete_timelimit  varchar(100) NOT NULL,
respon_depuer int(10) NOT NULL,
respon_depid int(10) NOT NULL,
follow_leader int(10) NOT NULL,
deal_result varchar(1000),
matter_file varchar(100),
sign_time varchar(100),
sign_user int(100),
sup_user int(100) NOT NULL,
eval_user int(100),
complete_time varchar(100),
create_time TIMESTAMP,
matter_state int(10) NOT NULL,  
PRIMARY KEY (matter_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists qh710_report;
create table qh710_report (
report_id int(10) unsigned NOT NULL AUTO_INCREMENT,
matter_id int(10) NOT NULL,
stage_name varchar(100),
stage_require varchar(200),
end_time varchar(100) NOT NULL,
dep_id int(10),
target_task varchar(200),
deal_progress varchar(200),
progress_state varchar(200),
progress_situ varchar(200),
report_problem varchar(200),
report_nextstep varchar(200),
report_file varchar(500),
create_time varchar(100),
update_time TIMESTAMP,
PRIMARY KEY (report_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


drop table if exists qh710_urge;
create table qh710_urge (
urge_id int(10) unsigned NOT NULL AUTO_INCREMENT,
matter_id int(10) NOT NULL,
urge_userid int(100) NOT NULL,
urge_time varchar(100) NOT NULL,
urge_content varchar(200) NOT NULL,
beurged_userid varchar(200) NOT NULL,
urge_file varchar(200),
urge_filename varchar(100),
create_time TIMESTAMP,
PRIMARY KEY (urge_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


drop table if exists qh710_comment;
create table qh710_comment (
comment_id int(10) unsigned NOT NULL AUTO_INCREMENT,
matter_id int(10) NOT NULL,
comment_user int(100) NOT NULL,
comment_content varchar(200),
create_time TIMESTAMP,
PRIMARY KEY (comment_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists qh710_apply;
create table qh710_apply (
apply_id int(10) unsigned NOT NULL AUTO_INCREMENT,
matter_id int(10) NOT NULL,
apply_user int(100) NOT NULL,
apply_type int(10) NOT NULL,
apply_content varchar(200),
apply_state int(10),
apply_time varchar(100),
create_time TIMESTAMP,
PRIMARY KEY (apply_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


drop table if exists qh710_log;
create table qh710_log (
log_id int(10) unsigned NOT NULL AUTO_INCREMENT,
matter_id int(10) NOT NULL,
log_user int(100) NOT NULL,
log_content int(200),
log_type int(10) NOT NULL,
create_time TIMESTAMP,
PRIMARY KEY (log_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


drop table if exists qh710_message;
create table qh710_message (
message_id int(10) unsigned NOT NULL AUTO_INCREMENT,
matter_id int(10) NOT NULL,
message_user int(100) NOT NULL,
message_content int(200),
create_time TIMESTAMP,
PRIMARY KEY (message_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;




